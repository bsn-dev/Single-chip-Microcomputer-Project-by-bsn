#include "reg52.h"			 

sbit led_power=P0^0;
sbit led_run=P0^1;
sbit engine=P1^0;
sbit run_button=P3^2;
sbit beef=P0^2;	
unsigned char second=0;

void Timer0Init()
{
	TMOD|=0X01;
	TH0=0XFC;	
	TL0=0X18;	
	ET0=1;
	EA=1;
	TR0=1;			
}

void delay(int i)
{
    while(i--);
}

void beef_run()
{
    int j;
    for ( j = 0; j < 500; j++)
    {
        beef=~beef;
        delay(100);
    }
}

void Int0Init()
{
    IT0=1;
    EX0=1;
    EA=1; 

}

void run() interrupt 0
{
	ET0=1;
    TH0=0XFC;	
	TL0=0X18;
    beef_run();
    Timer0Init();
}

void led_timer() interrupt 1
{
	static int i=0;
	engine=1;
	TH0=0XFC;	
	TL0=0X18;
	i++;
	if(i==500)
	{
	    if(second==10)
	    {
		    led_run=0;
			engine=0;
			ET0=0;
			second=0;
            beef_run();
			Int0Init();
	    }
		i=0;
		led_run=~led_run;
		second++;	
	}	
}

void main()
{	
    led_power=0;
	led_run=1;
	engine=0;
    Int0Init();	 
	while(1);		
}